unalias c gc p2i p3i pi cdDO cdSD la l
unset PROMPT_USERNAME
unset -f pshmode-auto-complete pshmode-fix