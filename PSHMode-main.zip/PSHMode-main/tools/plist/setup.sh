mkdir bin &> /dev/null
g++ loops.cpp -o bin/plist
